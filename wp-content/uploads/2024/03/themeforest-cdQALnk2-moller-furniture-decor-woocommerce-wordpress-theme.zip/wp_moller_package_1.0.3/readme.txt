04/06/2023: Updated version 1.0.3
	- Fixed: Image Zoom, Testimonial
	- Updated: WooCommerce 7.x

10/12/2021: Updated version 1.0.2
	- Updated YITH WooCommerce Zoom Magnifier version 2.1.1
	
07/24/2021: Updated version 1.0.1
	- Updated WordPress 5.8