VC-Template-Manager
===================

Template management for Visual Composer
